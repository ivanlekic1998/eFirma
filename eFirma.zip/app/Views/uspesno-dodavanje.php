<?php


echo "USPESNO IZMENJEN KLIJENT";

sleep(5);
