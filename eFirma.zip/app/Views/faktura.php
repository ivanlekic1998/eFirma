
<?php foreach ($data as $podatak) ?>
<h1 id="cena">Cena je: <?= $podatak->cena ?> </h1>
<h3>Treba odraditi template HTML fakture // Nisam imao vremena :)</h3>
